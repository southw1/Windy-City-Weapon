const weaponPools={
tier1:[{name:'Pistol',customName:'Beretta'},{name:'Pistol Mk II',customName:'Glock 45'},{name:'Combat Pistol',customName:'G19x'},{name:'SNS Pistol',customName:'Walter P90'},{name:'SNS Pistol Mk II',customName:'Hellcat'},{name:'Heavy Pistol',customName:'FN'},{name:'Vintage Pistol',customName:'Glock 41'},{name:'Ceramic Pistol',customName:'SigP230'}],
show1_5:[{name:'SMG',customName:'Banshee ARP'},{name:'SMG Mk II',customName:'4 Inch ARP (FRT)'},{name:'Machine Pistol',customName:'Tec 9'},{name:'AP Pistol',customName:'G47 Switch'},{name:'Pistol .50',customName:'FN 57'},{name:'Heavy Pistol',customName:'FN'},{name:'WM 29 Pistol',customName:'Glock 30'},{name:'Compact Rifle',customName:'Micro Draco'},{name:'Heavy Rifle',customName:'Honey Badger'}],
tier2:[{name:'Carbine Rifle',customName:'300 Blackout'},{name:'Carbine Rifle Mk II',customName:'Micro ARP'},{name:'Compact Rifle',customName:'Black Draco'},{name:'AP Pistol',customName:'G47 Switch'},{name:'Micro SMG',customName:'Kriss Vector'},{name:'Tactical SMG',customName:'Mac 10'},{name:'Combat PDW',customName:'DDM4'}]
};
let current='tier1';
function showTier(t){current=t;const c=document.getElementById('weaponPool');c.innerHTML='';weaponPools[t].forEach(w=>c.innerHTML+=`<div class="weapon-card"><b>${w.customName}</b><br><small>${w.name}</small></div>`);}
function randomizeWeapon(){const w=weaponPools[current][Math.floor(Math.random()*weaponPools[current].length)];document.getElementById('selectedWeapon').innerHTML=`<h2>${w.customName}</h2><p>${w.name}</p>`;}
function showInfo(){alert('Windy City Weapons');}
window.onload=()=>showTier('tier1');
